<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bdstudent";

$con = mysqli_connect($servername, $username, $password ,$dbname);

/*if($conn->connect_error){
    die('Erreur : ' .$conn->connect_error);
}
echo 'Connexion réussie';*/
 
?>